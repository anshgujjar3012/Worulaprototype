import React, { createContext, useContext } from 'react';
import { ColorValue } from 'react-native';

export const colors = {
  primary: '#5865F2',
  background: '#0B1220',
  card: '#121A2B',
  text: '#E6E9F0',
  muted: '#8A93A6',
  success: '#22C55E',
  danger: '#EF4444',
  border: '#1F2A44'
};

type ThemeContext = { colors: typeof colors };
const ThemeCtx = createContext<ThemeContext>({ colors });

export const AppProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  return <ThemeCtx.Provider value={{ colors }}>{children}</ThemeCtx.Provider>;
};

export const useTheme = () => useContext(ThemeCtx);
export type Color = ColorValue;
