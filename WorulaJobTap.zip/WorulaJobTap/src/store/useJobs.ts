import { create } from 'zustand';
import { fetchJobs, createJob, updateJob, removeJob } from '@/services/api';

export type Job = {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: number;
  type: 'Full-time' | 'Part-time' | 'Contract' | 'Internship';
  createdAt: number;
};

type State = {
  loading: boolean;
  items: Job[];
  refresh: () => Promise<void>;
  add: (job: Omit<Job, 'id' | 'createdAt'>) => Promise<void>;
  edit: (job: Job) => Promise<void>;
  remove: (id: string) => Promise<void>;
};

export const useJobs = create<State>((set, get) => ({
  loading: false,
  items: [],
  refresh: async () => {
    set({ loading: true });
    const items = await fetchJobs();
    set({ items, loading: false });
  },
  add: async (job) => {
    const newJob = { ...job, id: Math.random().toString(36).slice(2), createdAt: Date.now() };
    await createJob(newJob);
    await get().refresh();
  },
  edit: async (job) => {
    await updateJob(job);
    await get().refresh();
  },
  remove: async (id) => {
    await removeJob(id);
    await get().refresh();
  }
}));

// Initial load
useJobs.getState().refresh();
