import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';

type User = { id: string; name: string; email: string } | null;

type State = {
  user: User;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (name: string, email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  init: () => Promise<void>;
};

const KEY = 'auth_user';

export const useAuth = create<State>((set, get) => ({
  user: null,
  init: async () => {
    const raw = await SecureStore.getItemAsync(KEY);
    if (raw) set({ user: JSON.parse(raw) });
  },
  signIn: async (email, password) => {
    // mock sign-in
    const user = { id: 'u1', name: 'Ansh', email };
    await SecureStore.setItemAsync(KEY, JSON.stringify(user));
    set({ user });
  },
  signUp: async (name, email, password) => {
    const user = { id: 'u1', name, email };
    await SecureStore.setItemAsync(KEY, JSON.stringify(user));
    set({ user });
  },
  signOut: async () => {
    await SecureStore.deleteItemAsync(KEY);
    set({ user: null });
  }
}));

// initialize on import
useAuth.getState().init();
