export const APP_NAME = 'Worula JobTap';
