// Mock API layer — in a real app swap these with real HTTP calls.
import { getItem, setItem } from './storage';
import type { Job } from '@/store/useJobs';

const JOBS_KEY = 'jobs@v1';

export async function fetchJobs(): Promise<Job[]> {
  return await getItem<Job[]>(JOBS_KEY, demoJobs);
}

export async function createJob(job: Job): Promise<Job> {
  const jobs = await fetchJobs();
  const updated = [job, ...jobs];
  await setItem(JOBS_KEY, updated);
  return job;
}

export async function updateJob(job: Job): Promise<Job> {
  const jobs = await fetchJobs();
  const updated = jobs.map(j => (j.id === job.id ? job : j));
  await setItem(JOBS_KEY, updated);
  return job;
}

export async function removeJob(id: string): Promise<void> {
  const jobs = await fetchJobs();
  await setItem(JOBS_KEY, jobs.filter(j => j.id !== id));
}

const demoJobs: Job[] = [
  {
    id: '1',
    title: 'React Native Developer',
    company: 'Worula Labs',
    location: 'Remote • India',
    description: 'Build beautiful mobile apps using Expo and React Native. Work with TypeScript, Zustand, and modern tooling.',
    salary: 1200000,
    type: 'Full-time',
    createdAt: Date.now() - 1000 * 60 * 60 * 5
  },
  {
    id: '2',
    title: 'Graphic Designer',
    company: 'JobTap Studios',
    location: 'Delhi, IN',
    description: 'Create clean, modern UI assets for mobile apps and social media campaigns.',
    salary: 600000,
    type: 'Contract',
    createdAt: Date.now() - 1000 * 60 * 60 * 24
  }
];
