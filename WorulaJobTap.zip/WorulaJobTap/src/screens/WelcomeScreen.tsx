import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import Button from '@/components/Button';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation';
import { APP_NAME } from '@/constants';

type Props = NativeStackScreenProps<RootStackParamList, 'Welcome'>;

export default function WelcomeScreen({ navigation }: Props) {
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>{APP_NAME}</Text>
      <Text style={styles.subtitle}>Find and post local jobs fast.</Text>

      <Button title="Sign In" onPress={() => navigation.navigate('SignIn')} style={{ marginTop: 24, width: '100%' }} />
      <Button title="Create Account" onPress={() => navigation.navigate('SignUp')} style={{ marginTop: 12, width: '100%' }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', alignItems: 'center', justifyContent: 'center', padding: 24 },
  logo: { color: 'white', fontSize: 28, fontWeight: '800' },
  subtitle: { color: '#9AA7C7', marginTop: 8, textAlign: 'center' }
});
