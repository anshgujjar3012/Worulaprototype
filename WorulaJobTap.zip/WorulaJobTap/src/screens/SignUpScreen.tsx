import React, { useState } from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import TextField from '@/components/TextField';
import Button from '@/components/Button';
import { signUpSchema } from '@/utils/validators';
import { useAuth } from '@/store/useAuth';

export default function SignUpScreen() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUp } = useAuth();

  const onSubmit = async () => {
    const parsed = signUpSchema.safeParse({ name, email, password });
    if (!parsed.success) return Alert.alert('Invalid', 'Fill your name, a valid email, and password (min 6).');
    setLoading(true);
    try {
      await signUp(name, email, password);
    } catch (e) {
      Alert.alert('Error', 'Failed to sign up.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Create your account</Text>
      <TextField placeholder="Name" value={name} onChangeText={setName} />
      <TextField placeholder="you@example.com" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
      <TextField placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />
      <Button title="Create Account" onPress={onSubmit} loading={loading} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16, justifyContent: 'center' },
  title: { color: 'white', fontSize: 24, fontWeight: '800', marginBottom: 16 }
});
