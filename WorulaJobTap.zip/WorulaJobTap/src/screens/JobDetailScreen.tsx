import React from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import { useRoute, useNavigation, RouteProp } from '@react-navigation/native';
import { useJobs } from '@/store/useJobs';
import Button from '@/components/Button';
import type { RootStackParamList } from '@/navigation';

export default function JobDetailScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'JobDetail'>>();
  const nav = useNavigation<any>();
  const { items, remove } = useJobs();
  const job = items.find(j => j.id === route.params.id);

  if (!job) return <View style={styles.container}><Text style={{ color: 'white' }}>Job not found.</Text></View>;

  const onDelete = async () => {
    await remove(job.id);
    Alert.alert('Deleted', 'Job removed.');
    nav.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{job.title}</Text>
      <Text style={styles.meta}>{job.company} • {job.location}</Text>
      <Text style={styles.desc}>{job.description}</Text>
      <Text style={styles.salary}>{job.salary ? `₹${job.salary.toLocaleString('en-IN')}` : 'Negotiable'}</Text>
      <Button title="Delete Job" onPress={onDelete} style={{ marginTop: 16 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16 },
  title: { color: 'white', fontSize: 22, fontWeight: '800' },
  meta: { color: '#A3AED0', marginTop: 6 },
  desc: { color: '#C7D2FE', marginTop: 12, lineHeight: 20 },
  salary: { color: '#22C55E', marginTop: 12, fontWeight: '800' }
});
