import React, { useEffect } from 'react';
import { View, FlatList, RefreshControl, StyleSheet } from 'react-native';
import JobCard from '@/components/JobCard';
import Empty from '@/components/Empty';
import Button from '@/components/Button';
import { useJobs } from '@/store/useJobs';
import { useNavigation } from '@react-navigation/native';

export default function JobsListScreen() {
  const { items, loading, refresh } = useJobs();
  const nav = useNavigation<any>();

  useEffect(() => { refresh(); }, []);

  return (
    <View style={styles.container}>
      <Button title="Post a Job" onPress={() => nav.navigate('PostJob')} />
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refresh} />}
        renderItem={({ item }) => (
          <JobCard item={item} onPress={() => nav.navigate('JobDetail', { id: item.id })} />
        )}
        ListEmptyComponent={<Empty title="No jobs yet" subtitle="Be the first to post a job." />}
        contentContainerStyle={{ paddingVertical: 12 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16 }
});
