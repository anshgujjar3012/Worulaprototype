import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Button from '@/components/Button';
import { useNavigation } from '@react-navigation/native';

export default function HomeScreen() {
  const nav = useNavigation<any>();
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to Worula JobTap 👋</Text>
      <Text style={styles.subtitle}>Browse local jobs, post opportunities, and connect fast.</Text>
      <Button title="Browse Jobs" onPress={() => nav.navigate('Jobs')} style={{ marginTop: 16 }} />
      <Button title="Post a Job" onPress={() => nav.navigate('PostJob')} style={{ marginTop: 12 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16, justifyContent: 'center' },
  title: { color: 'white', fontSize: 22, fontWeight: '800' },
  subtitle: { color: '#9AA7C7', marginTop: 6 }
});
