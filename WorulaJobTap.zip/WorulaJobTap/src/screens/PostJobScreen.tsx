import React, { useState } from 'react';
import { View, StyleSheet, Alert } from 'react-native';
import TextField from '@/components/TextField';
import Button from '@/components/Button';
import { useJobs } from '@/store/useJobs';

export default function PostJobScreen() {
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [location, setLocation] = useState('');
  const [salary, setSalary] = useState('');
  const [type, setType] = useState<'Full-time' | 'Part-time' | 'Contract' | 'Internship'>('Full-time');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const { add } = useJobs();

  const onSubmit = async () => {
    if (!title || !company || !location || !description) return Alert.alert('Missing info', 'Please fill all fields.');
    setLoading(true);
    try {
      await add({
        title, company, location, description,
        salary: salary ? Number(salary) : undefined, type
      });
      Alert.alert('Posted', 'Your job is live.');
      setTitle(''); setCompany(''); setLocation(''); setSalary(''); setDescription('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <TextField placeholder="Job title" value={title} onChangeText={setTitle} />
      <TextField placeholder="Company" value={company} onChangeText={setCompany} />
      <TextField placeholder="Location" value={location} onChangeText={setLocation} />
      <TextField placeholder="Salary (₹)" keyboardType="numeric" value={salary} onChangeText={setSalary} />
      <TextField placeholder="Type (Full-time/Part-time/Contract/Internship)" value={type} onChangeText={(t) => setType(t as any)} />
      <TextField placeholder="Description" value={description} onChangeText={setDescription} multiline />
      <Button title="Post Job" onPress={onSubmit} loading={loading} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16 }
});
