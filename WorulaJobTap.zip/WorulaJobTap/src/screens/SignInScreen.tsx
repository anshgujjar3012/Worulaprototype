import React, { useState } from 'react';
import { View, Text, StyleSheet, Alert } from 'react-native';
import TextField from '@/components/TextField';
import Button from '@/components/Button';
import { signInSchema } from '@/utils/validators';
import { useAuth } from '@/store/useAuth';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'SignIn'>;

export default function SignInScreen({ navigation }: Props) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();

  const onSubmit = async () => {
    const parsed = signInSchema.safeParse({ email, password });
    if (!parsed.success) return Alert.alert('Invalid', 'Please enter valid email & password (min 6 chars).');
    setLoading(true);
    try {
      await signIn(email, password);
    } catch (e) {
      Alert.alert('Error', 'Failed to sign in.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome back</Text>
      <TextField placeholder="you@example.com" autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
      <TextField placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />
      <Button title="Sign In" onPress={onSubmit} loading={loading} />
      <Text style={styles.link} onPress={() => navigation.navigate('SignUp')}>New here? Create an account</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16, justifyContent: 'center' },
  title: { color: 'white', fontSize: 24, fontWeight: '800', marginBottom: 16 },
  link: { color: '#93C5FD', marginTop: 12, textAlign: 'center' }
});
