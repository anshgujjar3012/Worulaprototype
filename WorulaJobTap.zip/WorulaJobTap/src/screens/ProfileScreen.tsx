import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Button from '@/components/Button';
import { useAuth } from '@/store/useAuth';

export default function ProfileScreen() {
  const { user, signOut } = useAuth();
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{user?.name}</Text>
      <Text style={styles.subtitle}>{user?.email}</Text>
      <Button title="Sign out" onPress={signOut} style={{ marginTop: 16 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0B1220', padding: 16 },
  title: { color: 'white', fontSize: 22, fontWeight: '800' },
  subtitle: { color: '#9AA7C7', marginTop: 6 }
});
