import React from 'react';
import { TextInput, StyleSheet, View, Text, TextInputProps } from 'react-native';
import { useTheme } from '@/theme';

type Props = TextInputProps & {
  label?: string;
  error?: string;
};

export default function TextField({ label, error, ...rest }: Props) {
  const { colors } = useTheme();
  return (
    <View style={styles.container}>
      {label ? <Text style={[styles.label, { color: colors.muted }]}>{label}</Text> : null}
      <TextInput
        placeholderTextColor={'#70819E'}
        style={[styles.input, { backgroundColor: '#0F172A', color: 'white', borderColor: colors.border }]}
        {...rest}
      />
      {error ? <Text style={[styles.error]}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 12 },
  label: { marginBottom: 6, fontSize: 13 },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 48
  },
  error: { color: '#EF4444', marginTop: 6, fontSize: 12 }
});
