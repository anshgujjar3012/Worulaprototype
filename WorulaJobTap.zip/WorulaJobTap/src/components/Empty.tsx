import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function Empty({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 24, alignItems: 'center' },
  title: { color: 'white', fontWeight: '700', fontSize: 16 },
  subtitle: { color: '#9AA7C7', marginTop: 6, textAlign: 'center' }
});
