import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useTheme } from '@/theme';
import { Job } from '@/store/useJobs';

type Props = { item: Job; onPress: () => void; };

export default function JobCard({ item, onPress }: Props) {
  const { colors } = useTheme();
  return (
    <TouchableOpacity onPress={onPress} style={[styles.card, { borderColor: colors.border }]} activeOpacity={0.85}>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.company}>{item.company} • {item.location}</Text>
      <Text numberOfLines={2} style={styles.desc}>{item.description}</Text>
      <View style={styles.footer}>
        <Text style={styles.salary}>{item.salary ? `₹${item.salary.toLocaleString('en-IN')}` : 'Negotiable'}</Text>
        <Text style={styles.type}>{item.type}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    backgroundColor: '#0F172A',
  },
  title: { color: 'white', fontWeight: '700', fontSize: 16 },
  company: { color: '#A3AED0', marginTop: 4 },
  desc: { color: '#C7D2FE', marginTop: 8 },
  footer: { marginTop: 12, flexDirection: 'row', justifyContent: 'space-between' },
  salary: { color: '#22C55E', fontWeight: '700' },
  type: { color: '#93C5FD', fontWeight: '600' }
});
