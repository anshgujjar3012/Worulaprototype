import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import WelcomeScreen from '@/screens/WelcomeScreen';
import SignInScreen from '@/screens/SignInScreen';
import SignUpScreen from '@/screens/SignUpScreen';
import Tabs from '@/navigation/tabs';
import JobDetailScreen from '@/screens/JobDetailScreen';
import PostJobScreen from '@/screens/PostJobScreen';
import { useAuth } from '@/store/useAuth';

export type RootStackParamList = {
  Welcome: undefined;
  SignIn: undefined;
  SignUp: undefined;
  Tabs: undefined;
  JobDetail: { id: string };
  PostJob: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const RootNavigator = () => {
  const { user } = useAuth();
  const initial = user ? 'Tabs' : 'Welcome';

  return (
    <Stack.Navigator initialRouteName={initial} screenOptions={{ headerShown: false }}>
      {!user ? (
        <>
          <Stack.Screen name="Welcome" component={WelcomeScreen} />
          <Stack.Screen name="SignIn" component={SignInScreen} />
          <Stack.Screen name="SignUp" component={SignUpScreen} />
        </>
      ) : (
        <>
          <Stack.Screen name="Tabs" component={Tabs} />
          <Stack.Screen name="JobDetail" component={JobDetailScreen} options={{ headerShown: true, title: 'Job Details' }} />
          <Stack.Screen name="PostJob" component={PostJobScreen} options={{ headerShown: true, title: 'Post a Job' }} />
        </>
      )}
    </Stack.Navigator>
  );
};

export default RootNavigator;
